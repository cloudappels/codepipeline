var describe = require("mocha").describe;
var expect = require("chai").expect;
var request = require("request");

describe("Settings functionality", function() {
    
    it ("Settings page status", function (done) {
        request("http://0.0.0.0:8081/settings", function (error, response, body) {
            expect(response.statusCode).to.equal(200);
            done();
        });
    });

    it("Updating settings page status", function (done) {
        request("http://0.0.0.0:8081/settings", function (error, response, body) {
            expect(response.statusCode).to.equal(200);
            done();
        });
    });

});




